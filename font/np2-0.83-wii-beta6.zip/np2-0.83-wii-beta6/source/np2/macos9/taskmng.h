
#ifdef __cplusplus
extern "C" {
#endif

void taskmng_exit(void);

#ifdef __cplusplus
}
#endif

