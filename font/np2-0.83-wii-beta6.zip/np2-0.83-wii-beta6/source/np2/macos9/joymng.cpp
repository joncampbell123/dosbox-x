#include	"compiler.h"
#include	"joymng.h"


BYTE joymng_getstat(void) {

	return(0xff);
}

