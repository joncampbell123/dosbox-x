#include	"compiler.h"
#include	"np2.h"
#include	"taskmng.h"


void taskmng_exit(void) {

	np2running = 0;
}

