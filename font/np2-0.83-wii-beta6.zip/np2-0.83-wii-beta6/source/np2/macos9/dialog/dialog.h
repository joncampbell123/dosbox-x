
void AboutDialogProc(void);
void ConfigDialogProc(void);
void MPU98DialogProc(void);
void CalendarDialogProc(void);

void ResumeErrorDialogProc(void);
int ResumeWarningDialogProc(const char *string);

void dialog_scropt(void);
void dialog_newdisk(void);
void dialog_changefdd(BYTE drv);
void dialog_changehdd(BYTE drv);
void dialog_font(void);
void dialog_writebmp(void);

