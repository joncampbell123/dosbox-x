
Handle GetDlgItem(DialogPtr hWnd, short pos);

BOOL dlgs_selectfile(char *name, int size);
BOOL dlgs_selectwritefile(char *name, int size, const char *def);

