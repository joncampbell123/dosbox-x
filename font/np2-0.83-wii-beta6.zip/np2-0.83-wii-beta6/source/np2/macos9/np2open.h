
void np2open(void);

