// CodeWarrior Prefix include file.
// Used by np21 classic.proj

#include	<MacHeaders.h>

#define	CPUCORE_IA32
#define	SUPPORT_PC9821

