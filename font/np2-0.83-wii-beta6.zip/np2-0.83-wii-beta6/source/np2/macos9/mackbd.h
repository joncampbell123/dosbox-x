
void mackbd_initialize(void);
void mackbd_callback(void);
BOOL mackbd_keydown(int keycode, BOOL cmd);
BOOL mackbd_keyup(int keycode);
void mackbd_activate(BOOL active);

void mackbd_resetf11(void);
void mackbd_resetf12(void);

