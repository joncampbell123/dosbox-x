// CodeWarrior Prefix include file.
// Used by np21.proj

#include	<MacHeadersCarbon.h>

#define	CPUCORE_IA32
#define	SUPPORT_PC9821

