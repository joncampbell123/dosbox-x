
#ifdef __cplusplus
extern "C" {
#endif

ARCH arcunzip_open(const OEMCHAR *path);

#ifdef __cplusplus
}
#endif

