
void v30cinit(void);

