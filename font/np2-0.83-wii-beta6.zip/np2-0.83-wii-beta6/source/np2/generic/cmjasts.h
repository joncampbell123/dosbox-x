
// ---- com manager jast sound

#ifdef __cplusplus
extern "C" {
#endif

COMMNG cmjasts_create(void);

#ifdef __cplusplus
}
#endif

