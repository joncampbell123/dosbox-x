
#ifdef __cplusplus
extern "C" {
#endif

void dmav30(void);

#ifdef __cplusplus
}
#endif

