
#ifdef __cplusplus
extern "C" {
#endif

void dmax86(void);

#ifdef __cplusplus
}
#endif

