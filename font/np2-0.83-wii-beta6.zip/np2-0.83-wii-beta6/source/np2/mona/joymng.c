#include	"compiler.h"
#include	"joymng.h"


UINT8 joymng_getstat(void) {

	return(0xff);
}

