
#ifdef __cplusplus
extern "C" {
#endif

UINT8 joymng_getstat(void);

#ifdef __cplusplus
}
#endif

