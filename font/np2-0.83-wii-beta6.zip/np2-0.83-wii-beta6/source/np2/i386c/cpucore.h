/*	$Id: cpucore.h,v 1.5 2004/06/15 13:50:13 monaka Exp $	*/

#ifndef	NP2_I386C_CPUCORE_H__
#define	NP2_I386C_CPUCORE_H__

#include "ia32/cpu.h"

#define	I286_MEMREADMAX		CPU_MEMREADMAX
#define	I286_MEMWRITEMAX	CPU_MEMWRITEMAX

#endif	/* !NP2_I386C_CPUCORE_H__ */
