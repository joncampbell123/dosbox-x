
extern const I286TBL op8xreg8_xtable[8];
extern const I286TBL op8xext8_xtable[8];
extern const I286TBL op8xreg16_xtable[8];
extern const I286TBL op8xext16_xtable[8];
extern const I286TBL op8xext16_atable[8];

extern const I286TBL sftreg8_xtable[8];
extern const I286TBL sftmem8_xtable[8];
extern const I286TBL sftext8_xtable[8];
extern const I286TBL sftreg16_xtable[8];
extern const I286TBL sftmem16_xtable[8];
extern const I286TBL sftext16_xtable[8];

extern const I286TBL sftreg8cl_xtable[8];
extern const I286TBL sftext8cl_xtable[8];
extern const I286TBL sftreg16cl_xtable[8];
extern const I286TBL sftext16cl_xtable[8];

extern const I286TBL ope0xf6_xtable[8];
extern const I286TBL ope0xf7_xtable[8];
extern const I286TBL ope0xfe_xtable[2];
extern const I286TBL ope0xff_xtable[8];

