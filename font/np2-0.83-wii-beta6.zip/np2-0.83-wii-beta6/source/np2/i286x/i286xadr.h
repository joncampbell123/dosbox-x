
extern	I286TBL	p_ea_dst[256];
extern	I286TBL	p_lea[256];
extern	I286TBL	p_get_ea[256];

