void rep_xinsb(void);
void rep_xinsw(void);
void rep_xoutsb(void);
void rep_xoutsw(void);
void rep_xmovsb(void);
void rep_xmovsw(void);
void rep_xlodsb(void);
void rep_xlodsw(void);
void rep_xstosb(void);
void rep_xstosw(void);

void repe_xcmpsb(void);
void repne_xcmpsb(void);
void repe_xcmpsw(void);
void repne_xcmpsw(void);

void repe_xscasb(void);
void repne_xscasb(void);
void repe_xscasw(void);
void repne_xscasw(void);
