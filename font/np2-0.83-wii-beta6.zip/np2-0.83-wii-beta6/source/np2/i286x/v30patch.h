
void v30xinit(void);

