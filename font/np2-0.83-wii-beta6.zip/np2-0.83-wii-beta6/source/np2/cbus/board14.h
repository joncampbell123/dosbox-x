
#ifdef __cplusplus
extern "C" {
#endif

void musicgenint(NEVENTITEM item);
UINT board14_pitcount(void);

void board14_allkeymake(void);

void board14_reset(const NP2CFG *pConfig);
void board14_bind(void);

#ifdef __cplusplus
}
#endif

