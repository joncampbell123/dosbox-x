
#ifdef __cplusplus
extern "C" {
#endif

void amd98_initialize(UINT rate);
void amd98_deinitialize(void);

void amd98int(NEVENTITEM item);

void amd98_bind(void);

#ifdef __cplusplus
}
#endif

