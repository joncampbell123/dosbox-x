

#ifdef __cplusplus
extern "C" {
#endif

void pcm86io_bind(void);

#ifdef __cplusplus
}
#endif

