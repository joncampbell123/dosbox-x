
#ifdef __cplusplus
extern "C" {
#endif

void boardx2_reset(const NP2CFG *pConfig);
void boardx2_bind(void);

#ifdef __cplusplus
}
#endif

