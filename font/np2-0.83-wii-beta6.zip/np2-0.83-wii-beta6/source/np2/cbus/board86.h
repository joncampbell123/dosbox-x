
#ifdef __cplusplus
extern "C" {
#endif

void board86_reset(const NP2CFG *pConfig);
void board86_bind(void);

void board86c_bind(void);

#ifdef __cplusplus
}
#endif

