
void *textout_open(const char *filename, int bufsize);
void textout_write(void *hdl, const char *string);
void textout_close(void *hdl);

