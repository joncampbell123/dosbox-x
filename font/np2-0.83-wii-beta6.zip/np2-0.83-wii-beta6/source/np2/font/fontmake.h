
#ifdef __cplusplus
extern "C" {
#endif

void makepc98bmp(const OEMCHAR *filename);

#ifdef __cplusplus
}
#endif

