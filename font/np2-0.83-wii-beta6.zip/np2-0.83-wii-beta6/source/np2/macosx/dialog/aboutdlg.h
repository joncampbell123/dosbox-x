/*
 *  aboutdlg.h
 *  np2x
 *
 *  Created by tk800 on Tue Nov 11 2003.
 *
 */



void AboutDialogProc(void);

