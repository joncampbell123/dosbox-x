/*
 *  soundopt.h
 *  np2
 *
 *  Created by tk800 on Sun Oct 26 2003.
 *
 */

#ifdef __cplusplus
extern "C" {
#endif

void initSoundOpt(void);

#ifdef __cplusplus
}
#endif
