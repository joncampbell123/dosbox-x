/*
 *  macclnd.h
 *  np2
 *
 *  Created by tk800 on Sat Jul 10 2004.
 *
 */


void initClnd( void );
