/*
 *  midiopt.h
 *  np2
 *
 *  Created by yk800 on Fri Oct 31 2003.
 *
 */
 
#ifdef __cplusplus
extern "C" {
#endif

void initMidiOpt(void);

#ifdef __cplusplus
}
#endif
