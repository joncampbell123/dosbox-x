/*
 *  screenopt.h
 *  np2
 *
 *  Created by tk800 on Fri Oct 24 2003.
 *
 */
 
#ifdef __cplusplus
extern "C" {
#endif

void initScreenOpt(void);

#ifdef __cplusplus
}
#endif
