/*
 *  configure.h
 *  from Neko Project IIx 0.3
 *
 *  Created by tk800 on Mon Sep 23 2002.
 *
 */

#ifdef __cplusplus
extern "C" {
#endif

void initConfig( void );

#ifdef __cplusplus
}
#endif
