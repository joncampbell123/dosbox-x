#ifdef __cplusplus
extern "C" {
#endif

void newdisk(void);

#ifdef __cplusplus
}
#endif

