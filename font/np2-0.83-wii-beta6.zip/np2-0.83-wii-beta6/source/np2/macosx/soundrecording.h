/*
 *  soundrecording.h
 *	from X1EMx
 *
 *  Created by tk800 on Fri Jan 31 2003.
 *
 */

#ifdef __cplusplus
extern "C" {
#endif

void recOPM(BYTE* work, int len);
int soundRec(bool end);

#ifdef __cplusplus
}
#endif

