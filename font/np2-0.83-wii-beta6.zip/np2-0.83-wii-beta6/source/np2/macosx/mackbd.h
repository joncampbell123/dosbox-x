
void mackbd_initialize(void);
void mackbd_callback(void);
void mackbd_keydown(int keycode);
void mackbd_keyup(int keycode);
void mackbd_resetf11(void);
void mackbd_resetf12(void);
