// CodeWarrior Prefix include file.
// Used by np2.proj

#ifdef __cplusplus

#include	<CarbonHeaders.h>

#else

#include	<MacHeadersCarbon.h>

#endif

#define	NP2CW

