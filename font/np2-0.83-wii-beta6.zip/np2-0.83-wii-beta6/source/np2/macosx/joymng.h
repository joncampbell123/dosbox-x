
#ifdef __cplusplus
extern "C" {
#endif

BYTE joymng_getstat(void);

#ifdef __cplusplus
}
#endif


void joy_flash(void);
