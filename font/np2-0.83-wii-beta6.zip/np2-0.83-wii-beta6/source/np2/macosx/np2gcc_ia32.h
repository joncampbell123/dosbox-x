// Apple Developer Builder include file.
// Used by np2.pbproj

#include <Carbon/Carbon.h>

#ifndef __MACOS__
#define	__MACOS__
#endif

#define	NP2GCC

#define CPUCORE_IA32
