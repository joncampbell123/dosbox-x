
#ifdef __cplusplus
extern "C" {
#endif

void fdd320_reset(const NP2CFG *pConfig);
void fdd320_bind(void);

#ifdef __cplusplus
}
#endif

