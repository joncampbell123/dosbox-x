
#ifdef __cplusplus
extern "C" {
#endif

void printif_reset(const NP2CFG *pConfig);
void printif_bind(void);

#ifdef __cplusplus
}
#endif

