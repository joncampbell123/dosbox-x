
#ifdef __cplusplus
extern "C" {
#endif

void cpuio_bind(void);

#ifdef __cplusplus
}
#endif

