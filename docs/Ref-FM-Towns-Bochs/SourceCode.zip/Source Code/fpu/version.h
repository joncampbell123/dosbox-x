/*---------------------------------------------------------------------------+
 |  version.h                                                                |
 |                                                                           |
 |                                                                           |
 | Copyright (C) 1992,1993,1994,1996,1997,1999                               |
 |                  W. Metzenthen, 22 Parker St, Ormond, Vic 3163, Australia |
 |                  E-mail   billm@melbpc.org.au                             |
 |                                                                           |
 |                                                                           |
 +---------------------------------------------------------------------------*/

#define FPU_VERSION "wm-FPU-emu version 2.05"
