#ifndef _I386_TYPES_H
#define _I386_TYPES_H

#ifndef __ASSEMBLY__
#endif

#endif  /* _I386_TYPES_H */
