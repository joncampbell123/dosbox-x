#ifndef _I386_UACCESS_H
#define _I386_UACCESS_H



#endif
