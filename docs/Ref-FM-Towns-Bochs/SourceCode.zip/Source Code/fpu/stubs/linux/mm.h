#ifndef _LINUX_MM_H
#define _LINUX_MM_H


#define VERIFY_READ 0
#define VERIFY_WRITE 1

#endif
