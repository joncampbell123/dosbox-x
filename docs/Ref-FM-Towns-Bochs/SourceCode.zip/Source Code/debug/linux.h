//
// linux.h
//

extern void do_linux_info ();
