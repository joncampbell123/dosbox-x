#define NEED_CPU_REG_SHORTCUTS 1
#include "bochs.h"
#define LOG_THIS BX_CPU_THIS_PTR
#if BX_USE_CPU_SMF
#define this (BX_CPU(0))
#endif

void BX_CPU_C::EXEC_lea16_O16regr_I16leD16(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit16u arg1;
Bit16u arg1_off;
Bit8u last;
Bit16u disp;

last=*(imm-1);
#if BX_NEED_WORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
#else
disp=*((Bit16u*)imm);
#endif

arg1_off=disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea16_O16regr_I16lerm161(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit16u arg1;
Bit16u arg1_off;
Bit8u last;

last=*(imm-1);

arg1_off = *(BX_CPU_THIS_PTR nemod_tbl1[last]);

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea16_O16regr_I16lerm161D16(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit16u arg1;
Bit16u arg1_off;
Bit8u last;
Bit16u disp;

last=*(imm-1);
#if BX_NEED_WORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
#else
disp=*((Bit16u*)imm);
#endif

arg1_off = *(BX_CPU_THIS_PTR nemod_tbl1[last]) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea16_O16regr_I16lerm161D8(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit16u arg1;
Bit16u arg1_off;
Bit8u last;
Bit8s disp;

last=*(imm-1);
disp=*imm;

arg1_off = *(BX_CPU_THIS_PTR nemod_tbl1[last]) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea16_O16regr_I16lerm162(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit16u arg1;
Bit16u arg1_off;
Bit8u last;

last=*(imm-1);

arg1_off = *(BX_CPU_THIS_PTR nemod_tbl1[last]) + *(BX_CPU_THIS_PTR nemod_tbl2[last]);

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea16_O16regr_I16lerm162D16(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit16u arg1;
Bit16u arg1_off;
Bit8u last;
Bit16u disp;

last=*(imm-1);
#if BX_NEED_WORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
#else
disp=*((Bit16u*)imm);
#endif

arg1_off = *(BX_CPU_THIS_PTR nemod_tbl1[last]) + *(BX_CPU_THIS_PTR nemod_tbl2[last]) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea16_O16regr_I16lerm162D8(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit16u arg1;
Bit16u arg1_off;
Bit8u last;
Bit8s disp;

last=*(imm-1);
disp=*imm;

arg1_off = *(BX_CPU_THIS_PTR nemod_tbl1[last]) + *(BX_CPU_THIS_PTR nemod_tbl2[last]) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea16_O32regr_I16leD16(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit16u arg1;
Bit16u arg1_off;
Bit8u last;
Bit16u disp;

last=*(imm-1);
#if BX_NEED_WORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
#else
disp=*((Bit16u*)imm);
#endif

arg1_off=disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea16_O32regr_I16lerm161(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit16u arg1;
Bit16u arg1_off;
Bit8u last;

last=*(imm-1);

arg1_off = *(BX_CPU_THIS_PTR nemod_tbl1[last]);

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea16_O32regr_I16lerm161D16(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit16u arg1;
Bit16u arg1_off;
Bit8u last;
Bit16u disp;

last=*(imm-1);
#if BX_NEED_WORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
#else
disp=*((Bit16u*)imm);
#endif

arg1_off = *(BX_CPU_THIS_PTR nemod_tbl1[last]) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea16_O32regr_I16lerm161D8(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit16u arg1;
Bit16u arg1_off;
Bit8u last;
Bit8s disp;

last=*(imm-1);
disp=*imm;

arg1_off = *(BX_CPU_THIS_PTR nemod_tbl1[last]) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea16_O32regr_I16lerm162(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit16u arg1;
Bit16u arg1_off;
Bit8u last;

last=*(imm-1);

arg1_off = *(BX_CPU_THIS_PTR nemod_tbl1[last]) + *(BX_CPU_THIS_PTR nemod_tbl2[last]);

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea16_O32regr_I16lerm162D16(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit16u arg1;
Bit16u arg1_off;
Bit8u last;
Bit16u disp;

last=*(imm-1);
#if BX_NEED_WORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
#else
disp=*((Bit16u*)imm);
#endif

arg1_off = *(BX_CPU_THIS_PTR nemod_tbl1[last]) + *(BX_CPU_THIS_PTR nemod_tbl2[last]) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea16_O32regr_I16lerm162D8(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit16u arg1;
Bit16u arg1_off;
Bit8u last;
Bit8s disp;

last=*(imm-1);
disp=*imm;

arg1_off = *(BX_CPU_THIS_PTR nemod_tbl1[last]) + *(BX_CPU_THIS_PTR nemod_tbl2[last]) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last&0x38)/8)=arg0;

}
