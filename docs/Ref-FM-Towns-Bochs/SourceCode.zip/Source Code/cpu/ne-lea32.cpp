#define NEED_CPU_REG_SHORTCUTS 1
#include "bochs.h"
#define LOG_THIS BX_CPU_THIS_PTR
#if BX_USE_CPU_SMF
#define this (BX_CPU(0))
#endif

void BX_CPU_C::EXEC_lea32_O16regr2_I32leD32(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last2;
Bit32u disp;

last2=*(imm-2);
#if BX_NEED_DWORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
disp|=(*(imm+2))<<16;
disp|=(*(imm+3))<<24;
#else
disp=*((Bit32u*)imm);
#endif

arg1_off=disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last2&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O16regr2_I32lerm321(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit8u last2;

last=*(imm-1);
last2=*(imm-2);

arg1_off = BX_READ_32BIT_REG(last&0x7);

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last2&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O16regr2_I32lerm321D32(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit8u last2;
Bit32u disp;

last=*(imm-1);
last2=*(imm-2);
#if BX_NEED_DWORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
disp|=(*(imm+2))<<16;
disp|=(*(imm+3))<<24;
#else
disp=*((Bit32u*)imm);
#endif

arg1_off = BX_READ_32BIT_REG(last&0x7) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last2&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O16regr2_I32lerm321D8(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit8u last2;
Bit8s disp;

last=*(imm-1);
last2=*(imm-2);
disp=*imm;

arg1_off = BX_READ_32BIT_REG(last&0x7) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last2&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O16regr2_I32lerm322D32(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit8u last2;
Bit32u disp;

last=*(imm-1);
last2=*(imm-2);
#if BX_NEED_DWORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
disp|=(*(imm+2))<<16;
disp|=(*(imm+3))<<24;
#else
disp=*((Bit32u*)imm);
#endif

arg1_off = (BX_READ_32BIT_REG((last&0x38)/8)<<((last&0xc0)/64)) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last2&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O16regr2_I32lerm323(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit8u last2;

last=*(imm-1);
last2=*(imm-2);

arg1_off = BX_READ_32BIT_REG(last&0x7) + (BX_READ_32BIT_REG((last&0x38)/8)<<((last&0xc0)/64));

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last2&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O16regr2_I32lerm323D32(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit8u last2;
Bit32u disp;

last=*(imm-1);
last2=*(imm-2);
#if BX_NEED_DWORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
disp|=(*(imm+2))<<16;
disp|=(*(imm+3))<<24;
#else
disp=*((Bit32u*)imm);
#endif

arg1_off = BX_READ_32BIT_REG(last&0x7) + (BX_READ_32BIT_REG((last&0x38)/8)<<((last&0xc0)/64)) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last2&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O16regr2_I32lerm323D8(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit8u last2;
Bit8s disp;

last=*(imm-1);
last2=*(imm-2);
disp=*imm;

arg1_off = BX_READ_32BIT_REG(last&0x7) + (BX_READ_32BIT_REG((last&0x38)/8)<<((last&0xc0)/64)) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last2&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O16regr_I32leD32(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit32u disp;

last=*(imm-1);
#if BX_NEED_DWORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
disp|=(*(imm+2))<<16;
disp|=(*(imm+3))<<24;
#else
disp=*((Bit32u*)imm);
#endif

arg1_off=disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O16regr_I32lerm321(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;

last=*(imm-1);

arg1_off = BX_READ_32BIT_REG(last&0x7);

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O16regr_I32lerm321D32(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit32u disp;

last=*(imm-1);
#if BX_NEED_DWORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
disp|=(*(imm+2))<<16;
disp|=(*(imm+3))<<24;
#else
disp=*((Bit32u*)imm);
#endif

arg1_off = BX_READ_32BIT_REG(last&0x7) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O16regr_I32lerm321D8(int seg,Bit8u* imm)
{
Bit16u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit8s disp;

last=*(imm-1);
disp=*imm;

arg1_off = BX_READ_32BIT_REG(last&0x7) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_16BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O32regr2_I32leD32(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last2;
Bit32u disp;

last2=*(imm-2);
#if BX_NEED_DWORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
disp|=(*(imm+2))<<16;
disp|=(*(imm+3))<<24;
#else
disp=*((Bit32u*)imm);
#endif

arg1_off=disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last2&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O32regr2_I32lerm321(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit8u last2;

last=*(imm-1);
last2=*(imm-2);

arg1_off = BX_READ_32BIT_REG(last&0x7);

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last2&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O32regr2_I32lerm321D32(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit8u last2;
Bit32u disp;

last=*(imm-1);
last2=*(imm-2);
#if BX_NEED_DWORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
disp|=(*(imm+2))<<16;
disp|=(*(imm+3))<<24;
#else
disp=*((Bit32u*)imm);
#endif

arg1_off = BX_READ_32BIT_REG(last&0x7) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last2&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O32regr2_I32lerm321D8(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit8u last2;
Bit8s disp;

last=*(imm-1);
last2=*(imm-2);
disp=*imm;

arg1_off = BX_READ_32BIT_REG(last&0x7) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last2&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O32regr2_I32lerm322D32(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit8u last2;
Bit32u disp;

last=*(imm-1);
last2=*(imm-2);
#if BX_NEED_DWORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
disp|=(*(imm+2))<<16;
disp|=(*(imm+3))<<24;
#else
disp=*((Bit32u*)imm);
#endif

arg1_off = (BX_READ_32BIT_REG((last&0x38)/8)<<((last&0xc0)/64)) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last2&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O32regr2_I32lerm323(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit8u last2;

last=*(imm-1);
last2=*(imm-2);

arg1_off = BX_READ_32BIT_REG(last&0x7) + (BX_READ_32BIT_REG((last&0x38)/8)<<((last&0xc0)/64));

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last2&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O32regr2_I32lerm323D32(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit8u last2;
Bit32u disp;

last=*(imm-1);
last2=*(imm-2);
#if BX_NEED_DWORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
disp|=(*(imm+2))<<16;
disp|=(*(imm+3))<<24;
#else
disp=*((Bit32u*)imm);
#endif

arg1_off = BX_READ_32BIT_REG(last&0x7) + (BX_READ_32BIT_REG((last&0x38)/8)<<((last&0xc0)/64)) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last2&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O32regr2_I32lerm323D8(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit8u last2;
Bit8s disp;

last=*(imm-1);
last2=*(imm-2);
disp=*imm;

arg1_off = BX_READ_32BIT_REG(last&0x7) + (BX_READ_32BIT_REG((last&0x38)/8)<<((last&0xc0)/64)) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last2&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O32regr_I32leD32(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit32u disp;

last=*(imm-1);
#if BX_NEED_DWORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
disp|=(*(imm+2))<<16;
disp|=(*(imm+3))<<24;
#else
disp=*((Bit32u*)imm);
#endif

arg1_off=disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O32regr_I32lerm321(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;

last=*(imm-1);

arg1_off = BX_READ_32BIT_REG(last&0x7);

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O32regr_I32lerm321D32(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit32u disp;

last=*(imm-1);
#if BX_NEED_DWORD_ALIGN || BX_BIG_ENDIAN
disp=*imm;
disp|=(*(imm+1))<<8;
disp|=(*(imm+2))<<16;
disp|=(*(imm+3))<<24;
#else
disp=*((Bit32u*)imm);
#endif

arg1_off = BX_READ_32BIT_REG(last&0x7) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last&0x38)/8)=arg0;

}

void BX_CPU_C::EXEC_lea32_O32regr_I32lerm321D8(int seg,Bit8u* imm)
{
Bit32u arg0;
Bit32u arg1;
Bit32u arg1_off;
Bit8u last;
Bit8s disp;

last=*(imm-1);
disp=*imm;

arg1_off = BX_READ_32BIT_REG(last&0x7) + disp;

arg1=arg1_off;

arg0=arg1;
BX_READ_32BIT_REG((last&0x38)/8)=arg0;

}
