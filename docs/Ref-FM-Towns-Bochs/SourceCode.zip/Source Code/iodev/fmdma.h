//  $Id: fmdma.h,v 1.2 2001/07/13 15:15:06 nishi Exp $
//
//  Copyright (C) 2001 Shouhei Nishi.
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA


#ifndef _PCDMA_H
#define _PCDMA_H


#define BX_KBD_ELEMENTS 16
#define BX_MOUSE_BUFF_SIZE 48


#if BX_USE_DMA_SMF
#  define BX_DMA_SMF  static
#  define BX_DMA_THIS bx_dma.
#else
#  define BX_DMA_SMF
#  define BX_DMA_THIS this->
#endif



class bx_dma_c : public logfunctions {
public:

  bx_dma_c();
  ~bx_dma_c(void);

  BX_DMA_SMF void     init(bx_devices_c *);
  BX_DMA_SMF void     DRQ(unsigned channel, Boolean val);
  BX_DMA_SMF void     raise_HLDA(bx_pc_system_c *pc_sys);

private:

  static Bit32u read_handler(void *this_ptr, Bit32u address, unsigned io_len);
  static void   write_handler(void *this_ptr, Bit32u address, Bit32u value, unsigned io_len);
#if !BX_USE_DMA_SMF
  Bit32u   read( Bit32u   address, unsigned io_len);
  void     write(Bit32u   address, Bit32u   value, unsigned io_len);
#endif
  BX_DMA_SMF Bit32u read_main( Bit32u   address);
  BX_DMA_SMF void   write_main(Bit32u   address, Bit32u   value);
  struct {
    Boolean base[2];
    int     channel[2];
    Boolean mask[8];
    Boolean RQ[8];
    Boolean TC[8];
    Boolean SRQ[8];
    struct {
      Boolean enable;
      struct {
        int     mode_type;
        Boolean address_decrement;
        Boolean autoinit_enable;
        int     transfer_type;
        Boolean word_transfer;
        } mode;
      Bit32u  base_address;
      Bit32u  current_address;
      Bit32u  extra_address;
      Bit16u  base_count;
      Bit16u  current_count;
      } chan[8]; /* DMA channels 0..7 */
    } s;  // state information

  bx_devices_c *devices;
  };

extern bx_dma_c bx_dma;

#endif  // #ifndef _PCDMA_H
